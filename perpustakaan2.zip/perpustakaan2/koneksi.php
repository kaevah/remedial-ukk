<?php
$koneksi = mysqli_connect('localhost','root','','perpustakan');
