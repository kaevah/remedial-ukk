<?php
$koneksi=mysqli_connect('localhost','root','','ukk_perpus');